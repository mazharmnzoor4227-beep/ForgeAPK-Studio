Drift City Ultra 3D V2
- Open index.html directly.
- Single-file build: no external JS/CDN/API.
- For APK/WebView: enable JavaScript, WebGL and hardware acceleration; landscape orientation recommended.
- GAS ▲ is the forward/accelerator button.
