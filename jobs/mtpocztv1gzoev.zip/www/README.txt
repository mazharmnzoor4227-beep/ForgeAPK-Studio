FORGEAPK STUDIO v9 FINAL — SINGLE APP ZIP

This is the one ZIP you upload into your working browser ForgeAPK Studio to build the final ForgeAPK Studio Android app.

Included:
- Premium mobile UI.
- First-time GitHub setup only.
- Premium permission/capability cards.
- Large + full-screen preview.
- Dedicated full-screen APK build processing page.
- Build stages and progress UI.
- Background build behavior:
  once upload + workflow dispatch succeeds, GitHub Actions continues building remotely even if ForgeAPK is minimized.
- Pending build is saved locally and status checking resumes when the app is opened again.
- In-app APK download + Android installer support.
- APK Installer capability card.
- Recent build history.
- Stable-update-compatible app source when used with the stable v6+ workflow.

BUILD THIS APP WITH:
App Name: ForgeAPK Studio
Package ID: com.forgeapk.studio

Capabilities to select for ForgeAPK Studio itself:
- Network
- APK Installer

IMPORTANT:
Android still requires its own Install/Update confirmation screen.
The actual GitHub build continues in the cloud, but if you minimize the app before the project upload / workflow dispatch completes, the build may not have started yet.
