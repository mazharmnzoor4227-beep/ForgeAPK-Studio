ForgeAPK Studio Premium v3

What was fixed:
- First-time GitHub setup modal is now fully scrollable on mobile.
- Save & Continue remains reachable on short screens and when the keyboard is open.
- Smooth focus scrolling for setup fields.
- Main page stays locked only while setup is open, then scrolls normally after setup is saved.
- More premium sections, permission cards, buttons, shadows, gradients and spacing.
- Setup still appears only on first launch; use the gear icon later to reopen it.
- GitHub token remains stored locally in app storage and is not hardcoded into source.

Build:
App Name: ForgeAPK Studio
Package ID: com.forgeapk.studio
Recommended builder permission: Network Status only.
