
(function(){

  const P=()=>window.Capacitor&&window.Capacitor.Plugins
    ?window.Capacitor.Plugins
    :{};

  window.NativeBridge={

    isNative:()=>!!(
      window.Capacitor &&
      window.Capacitor.isNativePlatform &&
      window.Capacitor.isNativePlatform()
    ),

    camera:async()=>{

      const p=P();

      if(!p.Camera)
        throw new Error('Camera plugin unavailable');

      return p.Camera.getPhoto({
        quality:85,
        resultType:'uri',
        source:'CAMERA'
      });
    },

    location:async()=>{

      const p=P();

      if(!p.Geolocation)
        throw new Error('Geolocation unavailable');

      await p.Geolocation.requestPermissions();

      return p.Geolocation.getCurrentPosition({
        enableHighAccuracy:true
      });
    },

    notify:async(title,body)=>{

      const p=P();

      if(!p.LocalNotifications)
        throw new Error('Notifications unavailable');

      await p.LocalNotifications.requestPermissions();

      return p.LocalNotifications.schedule({
        notifications:[
          {
            title:title||'Notification',
            body:body||'',
            id:Date.now()%2147483647,
            schedule:{
              at:new Date(
                Date.now()+1000
              )
            }
          }
        ]
      });
    },

    share:async(title,text,url)=>{

      const p=P();

      if(!p.Share)
        throw new Error('Share unavailable');

      return p.Share.share({
        title:title||'',
        text:text||'',
        url:url||''
      });
    },

    vibrate:async()=>{

      const p=P();

      if(!p.Haptics)
        throw new Error('Haptics unavailable');

      return p.Haptics.impact({
        style:'MEDIUM'
      });
    },

    network:async()=>{

      const p=P();

      if(!p.Network)
        throw new Error('Network plugin unavailable');

      return p.Network.getStatus();
    },

    device:async()=>{

      const p=P();

      if(!p.Device)
        throw new Error('Device plugin unavailable');

      return p.Device.getInfo();
    },

    writeTextFile:async(name,text)=>{

      const p=P();

      if(!p.Filesystem)
        throw new Error('Filesystem unavailable');

      return p.Filesystem.writeFile({
        path:name||'file.txt',
        data:text||'',
        directory:'DOCUMENTS',
        encoding:'utf8'
      });
    },

    pickImages:async()=>{

      const p=P();

      if(
        p.Camera &&
        p.Camera.pickImages
      )
        return p.Camera.pickImages({
          quality:90,
          limit:0
        });

      throw new Error(
        'Gallery picker unavailable'
      );
    },

    pickLocalFile:(accept='*/*')=>
      new Promise(
        (resolve,reject)=>{

          try{

            const i=
              document.createElement(
                'input'
              );

            i.type='file';
            i.accept=accept;

            i.onchange=()=>{

              const f=
                i.files &&
                i.files[0];

              if(!f)
                return resolve(null);

              resolve({
                file:f,
                url:URL.createObjectURL(f),
                name:f.name,
                type:f.type,
                size:f.size
              });
            };

            i.click();

          }catch(e){

            reject(e);
          }
        }
      ),

    pickAudio:()=>
      window.NativeBridge.pickLocalFile(
        'audio/*'
      ),

    pickVideo:()=>
      window.NativeBridge.pickLocalFile(
        'video/*'
      ),

    pickPhoto:()=>
      window.NativeBridge.pickLocalFile(
        'image/*'
      ),

    bgAudioPlay:async(
      url,
      title='Now Playing'
    )=>{

      const p=P();

      if(!p.BackgroundAudio)
        throw new Error(
          'Background audio unavailable'
        );

      return p.BackgroundAudio.play({
        url,
        title
      });
    },

    bgAudioPause:async()=>{

      const p=P();

      if(!p.BackgroundAudio)
        throw new Error(
          'Background audio unavailable'
        );

      return p.BackgroundAudio.pause();
    },

    bgAudioResume:async()=>{

      const p=P();

      if(!p.BackgroundAudio)
        throw new Error(
          'Background audio unavailable'
        );

      return p.BackgroundAudio.resume();
    },

    bgAudioStop:async()=>{

      const p=P();

      if(!p.BackgroundAudio)
        throw new Error(
          'Background audio unavailable'
        );

      return p.BackgroundAudio.stop();
    }
  };

})();
