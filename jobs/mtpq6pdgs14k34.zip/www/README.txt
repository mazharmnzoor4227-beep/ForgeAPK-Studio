FORGEAPK STUDIO v11 UNIVERSAL COMMON CAPABILITIES

One-time builder upgrade for common Android app/game/media capabilities.

Existing:
Camera, Microphone, Location, Notifications, Files, Network, Photos,
Music/Audio, Video, Background Audio, Haptics, Share, APK Installer.

Added:
Bluetooth
NFC
Biometric
Contacts
Calendar
Activity Recognition
Background Tasks

Also installs more free official Capacitor plugins:
Preferences, Browser, Clipboard, Dialog, Toast, App, Keyboard, Motion.

IMPORTANT:
A permission in AndroidManifest does NOT automatically implement a full native feature.
For example Bluetooth/NFC/Biometric apps still need app code or a native bridge/API that uses
that permission. This upgrade means you should not need another workflow edit merely to declare
these common permissions.

Excluded on purpose:
SMS/call-log access, accessibility-service control, system overlay, all-files access,
device-admin, and other highly restricted/special Android privileges.
Those are not normal general-purpose permissions and can create safety/Play Store problems.
