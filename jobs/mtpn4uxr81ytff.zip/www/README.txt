ForgeAPK Studio Premium v4

Fix:
- The top ForgeAPK Studio header is no longer sticky.
- It scrolls away naturally instead of touching/merging with the Android status bar.
- Added safe-area spacing for phones with notches/status bars.
- Added a subtle premium divider below the header.

All v3 premium UI, first-time setup, scrolling fixes, permissions cards and builder logic are preserved.
