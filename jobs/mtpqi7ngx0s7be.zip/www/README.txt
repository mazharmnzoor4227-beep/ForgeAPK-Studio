NOVA PLAYER PRO — MX-STYLE TEST APP

Built for the ForgeAPK v11 Universal workflow.

Core experience:
- First launch permission screen
- Native Android MediaStore scan
- Automatically lists videos, music and photos after permission is allowed
- Search across local media
- Video thumbnails
- Video player with fullscreen system controls, speed selection and ±10 sec seek
- Photo viewer
- Music list
- Background audio through ForgeAPK BackgroundAudio bridge when supported
- Premium dark mobile UI

BUILD SETTINGS:
App Name: Nova Player Pro
Package ID: com.nova.playerpro

Select these capabilities:
- Photos
- Music / Audio
- Video
- Files
- Notifications
- Background Audio

Optional:
- Network

IMPORTANT LIMITATION:
This is an original media-player app, not MX Player itself. Codec/format support depends on
Android's media stack/WebView. Advanced proprietary codecs, DRM, casting, subtitle engines,
hardware-decoder tuning, network streaming protocols, etc. require additional native development.
