Pulse Player test app for ForgeAPK Studio.

Use in ForgeAPK Studio:
- Upload ZIP
- App Name: Pulse Player
- Package ID: com.pulse.player
- Select permissions/features:
  Music / Audio
  Files
  Notifications
  Background Audio
- Generate APK

In browser preview, normal playback works.
In the generated APK, Background Mode uses NativeBridge background audio support.
