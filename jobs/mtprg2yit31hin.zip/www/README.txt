AURORA MEDIA PRO

Premium local media player test app for ForgeAPK Studio.

Features:
- Music / audio player
- 10-second seek controls
- Local file playback
- Background Audio mode via ForgeAPK NativeBridge when available
- Video player with fullscreen
- Photo viewer
- Multi-photo gallery
- Premium mobile UI
- Offline media playback after local selection

Recommended ForgeAPK Studio build settings:
App Name: Aurora Media Pro
Package ID: com.aurora.mediapro

Select capabilities:
- Files
- Photos
- Music / Audio
- Video
- Notifications
- Background Audio
- Network (optional)

Note:
Normal local music/video/photo playback uses Android WebView file pickers.
True native background playback depends on the ForgeAPK BackgroundAudio bridge and whether
the selected local audio URI is accessible to Android MediaPlayer. Temporary blob: URLs are
not guaranteed to work as native background sources on every phone.
