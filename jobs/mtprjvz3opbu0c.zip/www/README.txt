FORGEAPK STUDIO v14 — TOP DARK BLUR HEADER

Changes:
- Fixed header kept in place.
- Strong black/dark treatment at the very top near Android time/Wi-Fi/battery.
- Header softly fades and blurs into the scrolling content below.
- Removed the hard bottom divider look.
- Added a modern glass/blur transition like premium mobile apps.
- Extra top spacing prevents content from crowding the fixed header.

Preserved:
- v13 in-app installer
- v12 Build Center / progress / ETA
- v11 universal capabilities

Build/update:
App Name: ForgeAPK Studio
Package ID: com.forgeapk.studio
Capabilities: Network + APK Installer
