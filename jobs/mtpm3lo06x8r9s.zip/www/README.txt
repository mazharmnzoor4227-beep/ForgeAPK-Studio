ForgeAPK Studio Android App

Upload this ZIP into your working ForgeAPK Studio builder.

Recommended:
App Name: ForgeAPK Studio
Package ID: com.forgeapk.studio

Permissions for the builder app itself:
- Network Status (optional)
No camera/mic/media permissions are required just to run the builder.

Important:
The GitHub token is not hardcoded into this package. On first launch of the APK,
enter/save your GitHub setup inside the app. Keeping the token out of the source
is safer than embedding it into a public repository.
