FORGEAPK STUDIO v13 — IN-APP APK INSTALL FLOW

Fix:
- Install no longer intentionally falls back to Chrome.
- Tapping Install opens a premium in-app confirmation sheet.
- APK downloads through the native ApkInstaller plugin inside ForgeAPK Studio.
- If Android requires "Allow from this source", ForgeAPK opens the official Android permission page.
- When the user returns, ForgeAPK automatically retries the installation.
- Android's secure system installer then opens with Install / Update confirmation.

Preserved:
- v12 fixed safe-area header
- sections scroll under header
- premium Build Center with stages, progress, elapsed time and ETA
- background/cloud build resume
- v11 Universal capabilities

Build/update settings:
App Name: ForgeAPK Studio
Package ID: com.forgeapk.studio
Select capabilities:
- Network
- APK Installer

IMPORTANT:
Android security does not allow a normal app to silently install another APK or replace the
system Install/Update confirmation. The final Install/Update button is always Android's own
secure installer screen.
